import ClientLayout from 'layouts/client'

export default function Home() {
  return <ClientLayout>Home page</ClientLayout>
}
