import { Box, Container, Toolbar } from '@mui/material'
import Header from './header'
import { ReactNode } from 'react'

export default function ClientLayout({ children }: { children: ReactNode }) {
  return (
    <>
      <Box>
        <Header />
        <Box
          component='main'
          sx={{
            flexGrow: 1,
            height: '100vh',
            overflow: 'auto'
          }}
        >
          {/* <Toolbar /> */}
          <Container sx={{ mt: 4, mb: 4 }}>{children}</Container>
        </Box>
      </Box>
    </>
  )
}
