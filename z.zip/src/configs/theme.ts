enum THEME {
  LIGHT = 'light',
  DARK = 'dark'
}

export default THEME
