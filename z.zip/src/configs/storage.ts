const LOCAL_KEY = {
  THEME: 'theme'
}

export default LOCAL_KEY
