import THEME from 'configs/theme'

export type ITheme = THEME.DARK | THEME.LIGHT
